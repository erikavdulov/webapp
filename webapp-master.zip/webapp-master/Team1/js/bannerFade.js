

$(function () {
  $('#banner').hide().fadeIn(2500);
});
