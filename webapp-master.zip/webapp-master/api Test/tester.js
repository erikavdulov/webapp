

const key = "ce8a57745882a7c9e177183a8a4dfae586f1bc8b";
//note: callback should be in global scope
function getData(s) {
console.log(s);
}
window.onload = runThis;




function runThis() {

const submit = document.getElementById('submit');
const search = document.getElementById('search');
submit.addEventListener('click', clickThis);

function clickThis() {
let ans = search.value;
const jsonpScript = document.createElement('script');
jsonpScript.src = `https://www.giantbomb.com/api/search/?api_key=${key}&format=jsonp&json_callback=getData&query=${ans}&resources=game`;
document.head.appendChild(jsonpScript);
}

}
